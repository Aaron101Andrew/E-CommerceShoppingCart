package com.example.allstudioprojects

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
